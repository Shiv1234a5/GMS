package com.gymapp.service;


import com.gymapp.dao.PersonDAO;
import com.gymapp.entities.Person;

public class PersonService {
    private PersonDAO personDAO = new PersonDAO();

    public void registerPerson(Person person) {
        personDAO.savePerson(person);
    }

    public Person loginPerson(String username, String password) {
        Person person = personDAO.getPersonByUsername(username);
        if (person != null && person.getPassword().equals(password)) {
            return person;
        }
        return null;
    }
}
