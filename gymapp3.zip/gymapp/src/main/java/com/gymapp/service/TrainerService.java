package com.gymapp.service;


import java.util.List;
import org.hibernate.SessionFactory;

import com.gymapp.dao.*;
import com.gymapp.entities.*;
import com.gymapp.utils.HibernateUtils;

public class TrainerService {
    private TrainerDAO trainerDAO = new TrainerDAO();
    
    
    private SessionFactory sessionFactory;

    public TrainerService() {
        this.sessionFactory = HibernateUtils.getSessionFactory();
    }

    
    
    
    public void registerTrainer(Trainer trainer) {
        trainerDAO.saveTrainer(trainer);
    }
    public void updateTrainer(Trainer trainer) {
        try {
            trainerDAO.updateTrainer(trainer);
            System.out.println("Trainer profile updated successfully.");
        } catch (Exception e) {
            System.out.println("Failed to update trainer profile.");
            e.printStackTrace();
        }
    }
    public void scheduleSession(int trainerId, String sessionDate, String sessionTime, String sessionDetails) {
        Session session = new Session();
        
        try {
            // Fetch the Trainer object using the trainerId
            Trainer trainer = trainerDAO.getTrainerById(trainerId); // Implement this method in your TrainerDAO

            // Set the Trainer object on the session
            session.setTrainer(trainer);
            session.setDate(sessionDate);
            session.setTime(sessionTime);
            session.setDetails(sessionDetails);

            // Save the session using SessionDAO
            trainerDAO.scheduleSession(session);
            System.out.println("Session scheduled successfully.");
        } catch (Exception e) {
            System.out.println("Failed to schedule session.");
            e.printStackTrace();
        }
    }

    
    
    public List<Session> getAllSessionsByTrainerId(int trainerId) {
        try (org.hibernate.Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Session WHERE trainer.id = :trainerId", Session.class)
                    .setParameter("trainerId", trainerId)
                    .list();
        }
    }



    public Trainer getTrainerById(int id) {
        return trainerDAO.getTrainerById(id);
    }
}
