package com.gymapp.service;


import com.gymapp.dao.SpecificationDAO;
import com.gymapp.entities.Specification;

public class SpecificationService {
    private SpecificationDAO specificationDAO = new SpecificationDAO();

    public void saveSpecification(Specification specification) {
        specificationDAO.saveSpecification(specification);
    }
}
