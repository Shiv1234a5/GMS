package com.gymapp.service;


import com.gymapp.dao.PaymentDAO;
import com.gymapp.entities.Payment;

public class PaymentService {
    private PaymentDAO paymentDAO = new PaymentDAO();

    public void savePayment(Payment payment) {
        paymentDAO.savePayment(payment);
    }
}
