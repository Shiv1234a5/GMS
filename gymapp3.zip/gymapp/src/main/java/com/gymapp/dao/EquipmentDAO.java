package com.gymapp.dao;


import com.gymapp.entities.Equipment;
import com.gymapp.utils.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class EquipmentDAO {

    public void saveEquipment(Equipment equipment) {
        Session session = HibernateUtils.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            session.save(equipment);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public List<Equipment> getAllEquipment() {
        Session session = HibernateUtils.getSessionFactory().openSession();
        List<Equipment> equipmentList = session.createQuery("from Equipment", Equipment.class).list();
        session.close();
        return equipmentList;
    }
}
