package com.gymapp.dao;

import com.gymapp.entities.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class SessionDAO {
    private SessionFactory sessionFactory;

    public SessionDAO(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public List<Session> getSessionsByTrainerId(int trainerId) {
        try (org.hibernate.Session hibernateSession = sessionFactory.openSession()) {
            String hql = "FROM Session WHERE trainerId = :trainerId";
            return hibernateSession.createQuery(hql, Session.class)
                                   .setParameter("trainerId", trainerId)
                                   .list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

