package com.gymapp.dao;
import org.hibernate.cfg.Configuration;
import com.gymapp.entities.Member;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.gymapp.utils.HibernateUtils;

public class MemberDAO extends PersonDAO {
	
	 public List<Member> getAllMembers() {
	        Session session = HibernateUtils.getSessionFactory().openSession();
	        List<Member> members = session.createQuery("from Member", Member.class).list();
	        session.close();
	        return members;
	    }
	 
	 
	 
    public void saveMember(Member member) {
        savePerson(member);
    }
    public void updateMember(Member member) {
        Transaction transaction = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(member);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public Member getMemberById(int id) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return session.get(Member.class, id);
        }
    }
}

