package com.gymapp.entities;

import javax.persistence.*;

@Entity
public class Member extends Person {
    private String membershipPlan;

	public String getMembershipPlan() {
		return membershipPlan;
	}

	public void setMembershipPlan(String membershipPlan) {
		this.membershipPlan = membershipPlan;
	}

    
}
